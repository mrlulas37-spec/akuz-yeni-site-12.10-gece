============================================================
  AKUZ STICKERS - cPanel KURULUM VE PAYTR ÖDEME REHBERİ
============================================================

Tebrikler! Bu paket AKUZ Stickers e-ticaret sitenizin, PayTR 
kredi kartı ödeme sistemi ve dinamik vitrin özellikleriyle 
birlikte cPanel için optimize edilmiş güncel sürümüdür.

------------------------------------------------------------
1. STATİK / PHP KURULUMU (ÖNERİLEN & EN HIZLI YOL)
------------------------------------------------------------
Dosya: cpanel_public_html_dist.zip

1. cPanel Dosya Yöneticisi'ne (File Manager) girin.
2. 'public_html' klasörünü açın.
3. Bu ZIP dosyasını yükleyin ve üzerine sağ tıklayıp 'Extract' (Çıkart) deyin.
4. Çıkan dosyalar doğrudan public_html içinde olmalıdır:
   - index.html
   - assets/ (CSS & JS dosyaları)
   - products/ (Görseller)
   - api/index.php (PayTR ve sipariş API motoru)
   - paytr-callback.php (PayTR bildirim adresi)
   - data_storage/ (Siparişler, ürünler ve PayTR ayarları)
   - uploads/ (Yüklenen ürün ve vitrin fotoğrafları)
   - .htaccess (Sayfa yönlendirmeleri ve API kuralları)

* data_storage ve uploads klasörlerinin yazma izninin (chmod) 755 veya 777 olduğundan 
  emin olun (Siparişlerin ve ürün fotoğraflarının kaydedilebilmesi için).

------------------------------------------------------------
2. PAYTR MAĞAZA PANELİ AYARLARI
------------------------------------------------------------
PayTR mağaza panelinize (https://www.paytr.com) giriş yapın:
1. Ayarlar -> Bildirim URL Ayarları bölümüne gidin.
2. Bildirim URL'inizi şu şekilde kaydedin:
   https://siteniz.com/paytr-callback.php
   veya
   https://siteniz.com/api/paytr/callback
3. 'Tekrar Kontrol Et' butonuna bastığınızda 'OK' yanıtı alınacak ve 
   sisteminiz yeşil yanacaktır.
4. Siteniz üzerinden /odeme sayfasına giderek bir test siparişi oluşturun.
   PayTR test kartı ile ödemeyi tamamlayın.
5. PayTR onayından sonra sitenizin Admin Panelinden (/admin)
   PayTR Canlı Modu'nu aktif edebilirsiniz.

------------------------------------------------------------
3. cPanel NODE.JS APP KURULUMU (İSTEĞE BAĞLI ALTERNATİF)
------------------------------------------------------------
Dosya: cpanel_full_app.zip

1. cPanel'de 'Setup Node.js App' bölümünü açın.
2. 'Create Application' deyin.
3. Node.js Version: 18.x veya 20.x seçin.
4. Application root: sitenizin klasörü
5. Application startup file: server.js veya app.js
6. ZIP içindeki dosyaları o klasöre çıkartın ve 'Run NPM Install' deyin.
7. 'Restart' butonuna basın.

Her iki kurulum yönteminde de PayTR Kredi Kartı (3D Secure) 
ödeme sistemi eksiksiz olarak çalışmaktadır.
============================================================
