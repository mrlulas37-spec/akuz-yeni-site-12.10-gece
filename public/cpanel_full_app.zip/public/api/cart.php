<?php
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");

require_once 'db.php';

$data = json_decode(file_get_contents("php://input"), true);

$action    = $data['action'] ?? 'list'; // 'add', 'remove', 'list'
$userId    = $data['user_id'] ?? null;
$productId = $data['product_id'] ?? null;
$quantity  = $data['quantity'] ?? 1;

if (!$userId) {
    echo json_encode(["status" => "error", "message" => "Kullanıcı girişi bulunamadı."]);
    exit;
}

// 1. Sepeti Listele
if ($action === 'list') {
    $stmt = $db->prepare("SELECT product_id, quantity FROM cart WHERE user_id = ?");
    $stmt->execute([$userId]);
    $items = $stmt->fetchAll();
    echo json_encode(["status" => "success", "cart" => $items]);
    exit;
}

// 2. Sepete Ekle
if ($action === 'add' && $productId) {
    // Ürün zaten var mı kontrol et, varsa adeti arttır
    $stmt = $db->prepare("SELECT id, quantity FROM cart WHERE user_id = ? AND product_id = ?");
    $stmt->execute([$userId, $productId]);
    $existing = $stmt->fetch();

    if ($existing) {
        $update = $db->prepare("UPDATE cart SET quantity = quantity + ? WHERE id = ?");
        $update->execute([$quantity, $existing['id']]);
    } else {
        $insert = $db->prepare("INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, ?)");
        $insert->execute([$userId, $productId, $quantity]);
    }
    echo json_encode(["status" => "success", "message" => "Ürün sepete eklendi."]);
    exit;
}

// 3. Sepetten Çıkar
if ($action === 'remove' && $productId) {
    $delete = $db->prepare("DELETE FROM cart WHERE user_id = ? AND product_id = ?");
    $delete->execute([$userId, $productId]);
    echo json_encode(["status" => "success", "message" => "Ürün sepetten silindi."]);
    exit;
}
?>
