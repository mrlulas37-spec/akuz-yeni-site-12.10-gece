<?php
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");

require_once 'db.php';

$data = json_decode(file_get_contents("php://input"), true);

$action    = $data['action'] ?? 'toggle'; // 'toggle', 'list'
$userId    = $data['user_id'] ?? null;
$productId = $data['product_id'] ?? null;

if (!$userId) {
    echo json_encode(["status" => "error", "message" => "Kullanıcı girişi bulunamadı."]);
    exit;
}

// 1. Favorileri Listele
if ($action === 'list') {
    $stmt = $db->prepare("SELECT product_id FROM favorites WHERE user_id = ?");
    $stmt->execute([$userId]);
    $favs = $stmt->fetchAll(PDO::FETCH_COLUMN);
    echo json_encode(["status" => "success", "favorites" => $favs]);
    exit;
}

// 2. Favoriye Ekle / Çıkar (Toggle)
if ($action === 'toggle' && $productId) {
    $check = $db->prepare("SELECT id FROM favorites WHERE user_id = ? AND product_id = ?");
    $check->execute([$userId, $productId]);
    
    if ($check->fetch()) {
        $delete = $db->prepare("DELETE FROM favorites WHERE user_id = ? AND product_id = ?");
        $delete->execute([$userId, $productId]);
        echo json_encode(["status" => "success", "isFavorite" => false, "message" => "Favorilerden kaldırıldı."]);
    } else {
        $insert = $db->prepare("INSERT INTO favorites (user_id, product_id) VALUES (?, ?)");
        $insert->execute([$userId, $productId]);
        echo json_encode(["status" => "success", "isFavorite" => true, "message" => "Favorilere eklendi."]);
    }
    exit;
}
?>
